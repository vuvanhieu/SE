.Group#1.Work out with Friends.
-
|
+-----> PDF		// PDF files of Report1, Report2, Report3
|
+-----> Slides		// powerpoint slides for demo1 ( We didn't use slides for demo2 )
|
+--+--> Code		// project code
   |
   +------> 1st version	// 1st version of the code
   |
   +------> 2nd version	// 2nd version of the code
   |
   +------> Data Structure_1st version	// Database illustration of 1st version of the code
   |
   +------> Data Structure_2nd version	// Database illustration of 2nd version of the code
+--+--> Design		// UML file
   |
   +------> design	// UML file