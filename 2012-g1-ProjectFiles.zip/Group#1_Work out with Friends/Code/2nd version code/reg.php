<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TemplateWorld - Shape</title>
<link href="css_reg.css" rel="stylesheet" type="text/css" />
<link rel="icon" href="images/icon.ico" />
</head>

<body>
<div id="headerbg">
  <div id="headerblank">
    <div id="header">
	<div id="menublank">
      <div id="menu">
        <ul>
          <li><a href="index.php" class="menu">Home </a></li>
          <li><a href="whysharing_how.php" class="menu">Why sharing & How </a></li>
          <li><a href="#" class="menu"> Top List </a></li>
          <li><a href="support.php" class="menu">Support</a></li>
        </ul>
      </div>
	  </div>
      <div id="headerrightblank">
        
<div class="contacts">
   <h2>Registration</h2>
   <p>User ID</p><input name="name" type="text" value="- enter your name -" onfocus="if(this.value=='- enter your name -')this.value=''" onblur="if(this.value=='')this.value='- enter your name -'"/>
   <p>Email</p><input name="name" type="text" value="- enter your email -" onfocus="if(this.value=='- enter your email -')this.value=''" onblur="if(this.value=='')this.value='- enter your email -'"/>
   <p>Key</p><input name="name" type="password" value="- enter your passwd -" onfocus="if(this.value=='- enter your passwd -')this.value=''" onblur="if(this.value=='')this.value='- enter your passwd -'"/>
   
   <p>Gender</p><input name="name" type="text" value="- enter M/F -" onfocus="if(this.value=='- enter M/F -')this.value=''" onblur="if(this.value=='')this.value='- enter M/F -'"/>
   <p>Age</p><input name="name" type="text" value="- enter your age -" onfocus="if(this.value=='- enter your age -')this.value=''" onblur="if(this.value=='')this.value='- enter your age -'"/>
   
   <div class="blank"></div><a href="#">Submit</a>
  </div>
      
        <div id="special">Work out with friends </div>
        <div id="year">2012</div>
		
        <div id="searchblank">
      
        </div>
      </div>
      
        
      </div>
      </div>
  </div>
</div>
<div id="contentbg">
  <div id="contentblank">
  
  

<div id="footerbg">
  <div id="footerblank">
    <div id="footer">
      <div id="footerlinks"><a href="#" class="footerlinks">Home</a> | <a href="#" class="footerlinks">About Our Company</a> | <a href="#" class="footerlinks">Blog</a> | <a href="#" class="footerlinks">Support</a> | <a href="#" class="footerlinks">Services Overview</a> | <a href="#" class="footerlinks">Testimonials</a> | <a href="#" class="footerlinks">Why Choose Us</a> | <a href="#" class="footerlinks">Contact Us</a></div>
      <div id="copyrights">© Copyright Information Goes Here. All Rights Reserved.</div>
      

    </div>
  </div>
</div>
</body>
</html>
