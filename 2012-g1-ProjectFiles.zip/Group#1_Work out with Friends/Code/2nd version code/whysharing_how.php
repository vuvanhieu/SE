<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TemplateWorld - Shape</title>
<link href="css_whysharing_how.css" rel="stylesheet" type="text/css" />
<link rel="icon" href="images/icon.ico" />
</head>

<body>
<div id="headerbg">
  <div id="headerblank">
    <div id="header">
	<div id="menublank">
      <div id="menu">
        <ul>
          <li><a href="index.php" class="menu">Home </a></li>
          <li><a href="whysharing_how.php" class="menu">Why sharing & How </a></li>
          <li><a href="#" class="menu"> Top List </a></li>
          <li><a href="support.php" class="menu">Support</a></li>
        </ul>
      </div>
	  </div>
	  
      <div id="headerrightblank">
	  Why sharing and How 
	  venenatis quis, fermentum sit amet, placerat quis, arcu. Donec at metus ut erat elementum sagittis. Nam aliquam. Suspendisse vehicula nulla non purus. Morbi ac odio. Fusce quis dui eu lectus egestas iaculis. Morbi non pede ac lacus fermentum vulputate.</div>
      
        
    </div>
      </div>
  </div>
</div>
<div id="contentbg">
  <div id="contentblank">
  
  

<div id="footerbg">
  <div id="footerblank">
    <div id="footer">
      <div id="footerlinks"><a href="#" class="footerlinks">Home</a> | <a href="#" class="footerlinks">About Our Company</a> | <a href="#" class="footerlinks">Blog</a> | <a href="#" class="footerlinks">Support</a> | <a href="#" class="footerlinks">Services Overview</a> | <a href="#" class="footerlinks">Testimonials</a> | <a href="#" class="footerlinks">Why Choose Us</a> | <a href="#" class="footerlinks">Contact Us</a></div>
      <div id="copyrights">© Copyright Information Goes Here. All Rights Reserved.</div>
      

    </div>
  </div>
</div>
</body>
</html>
