Workout With Friends -- Find motivation through competition.

By: Abdul Hassan <abdulrhass@gmail.com>
Date: 10/27/2012

Workout with friends is a class project.

--------------------------------------------------------------------------------

Copyright

--------------------------------------------------------------------------------

Dependencies

--------------------------------------------------------------------------------

Installation

The project can be run on a virtual machine using Vagrant (http://vagrantup.com/).
Enter the following commands from the root directory of this project.

*   vagrant up
*   vagrant ssh
*   cd /vagrant/
*   sudo python setup.py develop
*   pserve --reload --monitor-restart development.ini

At this point, you should be able to view the project on your host machine by
visiting 10.10.10.10:6543 from your browser.

--------------------------------------------------------------------------------

Usage

--------------------------------------------------------------------------------

Authors

--------------------------------------------------------------------------------